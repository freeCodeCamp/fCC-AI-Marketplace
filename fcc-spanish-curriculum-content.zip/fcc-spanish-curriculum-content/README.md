# freeCodeCamp Professional Spanish — Curriculum Content

Task files for the freeCodeCamp Professional Spanish course, organized by CEFR level, chapter, and module.

---

## Structure

```
curriculum/
└── spanish/
    ├── a1/
    │   ├── [Chapter Name]/
    │   │   └── [Module Name]/
    │   │       ├── WARM-UP_task-1.md
    │   │       ├── LEARN_task-1.md
    │   │       ├── LEARN_task-2.md
    │   │       ├── PRACTICE_task-1.md
    │   │       ├── REVIEW-GRAMMAR_task-1.md
    │   │       ├── REVIEW-GLOSSARY_task-1.md
    │   │       └── QUIZ_task-1.md
    ├── a2/
    └── b1/
```

---

## Contributing

Task files are created by the Marcos agent (part of the `fcc-spanish-curriculum-plugin`).

**Never write directly to `main`.** All work goes on a feature branch:

```bash
git checkout -b feat/[chapter-slug]-[module-slug]
# example:
git checkout -b feat/describing-a-company-module-2
```

Open a Pull Request when tasks are ready for review. The PR link goes into the planning spreadsheet's "PR Links/notes" column.

---

## Planning spreadsheet

Module planning lives in Google Sheets — not in this repo. Ask the team lead for the sheet URL.
